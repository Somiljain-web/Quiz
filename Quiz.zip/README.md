﻿# Quiz
Interactive Code With AI Quiz application built with HTML, CSS, and JavaScript.

**Student:** Somil Jain
